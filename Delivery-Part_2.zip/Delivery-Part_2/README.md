# KaffeDb

A python/sqlite application used to describe Coffee

### Vscode

Download the [SQLite](https://marketplace.visualstudio.com/items?itemName=alexcvzz.vscode-sqlite) extention in vscode and open the command pallet and run "SQLite: Open Database" og choose the file Coffee.db to open the Coffee.db database

### Running the Application

To run the application, simply open a terminal and type the following command:

```bash

python Coffee.py

```
